gdjs.Downhill_32Bike_32DemoCode = {};
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final = [];

gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects5= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects1= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects2= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4= [];
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects5= [];

gdjs.Downhill_32Bike_32DemoCode.conditionTrue_0 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_0 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.condition2IsTrue_0 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.condition2IsTrue_1 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2 = {val:false};
gdjs.Downhill_32Bike_32DemoCode.condition2IsTrue_2 = {val:false};


gdjs.Downhill_32Bike_32DemoCode.eventsList0 = function(runtimeScene) {

{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.isMobile());
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "Mobile");
}}

}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.systemInfo.isMobile();
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Backward"), gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2);
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1, gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2);

gdjs.copyArray(runtimeScene.getObjects("DesktopControls"), gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2);
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects1, gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2);

gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2);
gdjs.copyArray(runtimeScene.getObjects("Retry"), gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2);
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDRightObjects1, gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2);

{gdjs.evtTools.window.setFullScreen(runtimeScene, true, true);
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2[i].setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2[i].setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2[i].setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2[i].setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2[i].setOpacity(180);
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2[i].hide();
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2);
gdjs.copyArray(runtimeScene.getObjects("Seat"), gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getBehavior("Physics2").addWeldJoint((gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointX("Seat")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointY("Seat")), (gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2[0].getPointX("Connect")), (( gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2[0].getPointY("Connect")), 0, 30, 1, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Crank"), gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2);
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointX("Crank")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointY("Crank")), (gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[0].getPointY("Centre")), false, 0, 0, 0, true, 10, 20, false, runtimeScene.getScene().getVariables().get("crank"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2);
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getBehavior("Physics2").addWheelJoint((gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointX("FrontWheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointY("FrontWheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0].getPointY("Centre")), 335, 14, 0.7, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2);
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getBehavior("Physics2").addWheelJoint((gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointX("RearWheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[i].getPointY("RearWheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0].getPointY("Centre")), 90, 14, 0.7, true, 1, 50, false, runtimeScene.getScene().getVariables().get("rearJoint"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2);
gdjs.copyArray(runtimeScene.getObjects("RearSuspension"), gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2[i].getPointX("WheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2[i].getPointY("WheelAxis")), (gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2[0].getPointY("Centre")), false, 12, 0.7, 0, true, 150, 0, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Crank"), gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2);
gdjs.copyArray(runtimeScene.getObjects("RPedal"), gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getPointX("RPedal")), (gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getPointY("RPedal")), (gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2[0].getPointY("Centre")), false, 0, 0, 0, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Crank"), gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2);
gdjs.copyArray(runtimeScene.getObjects("LPedal"), gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getPointX("LPedal")), (gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getPointY("LPedal")), (gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2[0].getPointX("Centre")), (( gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2[0].getPointY("Centre")), false, 0, 0, 0, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointX("SeatConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointY("SeatConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0].getPointX("Sit")), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0].getPointY("Sit")), true, 0, -(10), 10, false, 0, 0, false, runtimeScene.getScene().getVariables().get("torsoForce"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Head"), gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointX("UConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointY("UConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2[0].getPointX("Connect")), (( gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2[0].getPointY("Connect")), true, 0, -(20), 20, false, 0, 0, false, runtimeScene.getScene().getVariables().get("headConn"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("RightThigh"), gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointX("LConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointY("LConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[0].getPointX("UConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[0].getPointY("UConnect")), false, 0, 100, -(45), false, 0, 0, false, runtimeScene.getScene().getVariables().get("rightThigh"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("LeftThigh"), gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointX("LConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointY("LConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[0].getPointX("UConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[0].getPointY("UConnect")), false, 0, 100, -(45), false, 0, 0, false, runtimeScene.getScene().getVariables().get("leftThigh"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightThigh"), gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getPointX("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getPointY("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[0].getPointX("LConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[0].getPointY("LConnect")), true, 0, -(130), 0, false, 0, 0, false, runtimeScene.getScene().getVariables().get("rightLeg"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftThigh"), gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getPointX("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getPointY("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[0].getPointX("LConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[0].getPointY("LConnect")), true, 0, -(130), 0, false, 0, 0, false, runtimeScene.getScene().getVariables().get("leftLeg"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("LPedal"), gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getPointX("Pedal")), (gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getPointY("Pedal")), (gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2[0].getPointX("Center")), (( gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2[0].getPointY("Center")), false, 0, -(10), 10, false, 0, 0, false, runtimeScene.getScene().getVariables().get("ragdollLpedal"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("RPedal"), gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getPointX("Pedal")), (gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getPointY("Pedal")), (gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2[0].getPointX("Center")), (( gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2[0].getPointY("Center")), false, 0, -(10), 10, false, 0, 0, false, runtimeScene.getScene().getVariables().get("ragdollRpedal"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("LUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointX("ArmConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointY("ArmConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2[0].getPointX("UConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2[0].getPointY("UConnect")), false, 0, 0, 0, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("RUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointX("ArmConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[i].getPointY("ArmConnect")), (gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2[0].getPointX("UConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2[0].getPointY("UConnect")), false, 0, 0, 0, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("RArm"), gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("RUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2[i].getPointX("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2[i].getPointY("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2[0].getPointX("LConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2[0].getPointY("LConnect")), true, 0, -(40), 85, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("LArm"), gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("LUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2[i].getPointX("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2[i].getPointY("Connect")), (gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2[0].getPointX("LConnect")), (( gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2[0].getPointY("LConnect")), true, 0, -(40), 85, false, 0, 0, false, gdjs.VariablesContainer.badVariable);
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("LArm"), gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2[i].getPointX("Handlebar")), (gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2[i].getPointY("Handlebar")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0].getPointX("Hands")), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0].getPointY("Hands")), false, 0, 0, 0, false, 0, 0, false, runtimeScene.getScene().getVariables().get("ragdollLhand"));
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1);
gdjs.copyArray(runtimeScene.getObjects("RArm"), gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1[i].getBehavior("Physics2").addRevoluteJointBetweenTwoBodies((gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1[i].getPointX("Handlebar")), (gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1[i].getPointY("Handlebar")), (gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0] : null), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0].getPointX("Hands")), (( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1[0].getPointY("Hands")), false, 0, 0, 0, false, 0, 0, false, runtimeScene.getScene().getVariables().get("ragdollRhand"));
}
}}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList1 = function(runtimeScene) {

{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Brake"), gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1);
gdjs.copyArray(runtimeScene.getObjects("Elapsed"), gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects1);
gdjs.copyArray(runtimeScene.getObjects("Forward"), gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects1);
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Downhill_32Bike_32DemoCode.GDRightObjects1);
gdjs.copyArray(runtimeScene.getObjects("Timing"), gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3000);
}{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}{runtimeScene.getScene().getVariables().getFromIndex(7).setNumber(0.18);
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects1[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) - 40);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightObjects1[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) - 40);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1[i].setX((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects1[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) - 260);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects1[i].setX(gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) - 140);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1[i].setWidth((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2));
}
}
{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList2 = function(runtimeScene) {

{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(14)) <= 1000;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
{runtimeScene.getScene().getVariables().getFromIndex(15).sub(1);
}}

}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(15)) > 0;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("186;255;66");
}
}}

}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(15)) > 250;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("250;237;86");
}
}}

}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(15)) > 500;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("245;166;35");
}
}}

}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(15)) > 750;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("255;105;65");
}
}}

}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(14)) > 1000;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4[i].setFillColor("255;0;0");
}
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("Force"), gdjs.Downhill_32Bike_32DemoCode.GDForceObjects3);
gdjs.copyArray(runtimeScene.getObjects("ForceIndicator"), gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3[i].drawLine((( gdjs.Downhill_32Bike_32DemoCode.GDForceObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDForceObjects3[0].getX()) + 20, 125, (( gdjs.Downhill_32Bike_32DemoCode.GDForceObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDForceObjects3[0].getX()) + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(15)) / 3) + 20, 125, 16);
}
}}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList3 = function(runtimeScene) {

{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(13).setNumber((( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getBehavior("Physics2").getJointReactionForce(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("torsoForce")))));
}}

}


{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(14));
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ForceStrength"), gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(14).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)));
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects3[i].setString(gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(14)))));
}
}}

}


{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)) > gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(15));
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
{runtimeScene.getScene().getVariables().getFromIndex(15).setNumber(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)));
}}

}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(15)) > 0;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList2(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)) > 100;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
{gdjs.deviceVibration.startVibration(50);
}}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList4 = function(runtimeScene) {

};gdjs.Downhill_32Bike_32DemoCode.eventsList5 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("LArm"), gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3);
gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3);
gdjs.copyArray(runtimeScene.getObjects("RArm"), gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3);
gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3);
gdjs.copyArray(runtimeScene.getObjects("Seat"), gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("torsoForce")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("ragdollRpedal")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("ragdollLpedal")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("ragdollRhand")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("ragdollLhand")));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftThigh"), gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightThigh"), gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("rightThigh")), true);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("leftThigh")), true);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("leftLeg")), true);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("rightLeg")), true);
}
}}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList6 = function(runtimeScene) {

};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDHeadObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDTorsoObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDRArmObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDLArmObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDRUpperArmObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDLUpperArmObjects2Objects = Hashtable.newFrom({"Head": gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2, "Torso": gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2, "RArm": gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2, "LArm": gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2, "RUpperArm": gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2, "LUpperArm": gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDfloorObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDJumpObjects2Objects = Hashtable.newFrom({"floor": gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects2, "Jump": gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects2});
gdjs.Downhill_32Bike_32DemoCode.eventsList7 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2, gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3);

gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3);
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2, gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3);

gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3);
gdjs.copyArray(runtimeScene.getObjects("Seat"), gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3);
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2, gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3);

{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("torsoForce")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("ragdollRpedal")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("ragdollLpedal")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("ragdollRhand")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("ragdollLhand")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[i].getBehavior("Physics2").removeJoint(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("headcoll")));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("LeftLeg"), gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("LeftThigh"), gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightLeg"), gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2);
gdjs.copyArray(runtimeScene.getObjects("RightThigh"), gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("rightThigh")), true);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("leftThigh")), true);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("leftLeg")), true);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2[i].getBehavior("Physics2").enableRevoluteJointLimits(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("rightLeg")), true);
}
}}

}


};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDForwardObjects4Objects = Hashtable.newFrom({"Forward": gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4});
gdjs.Downhill_32Bike_32DemoCode.eventsList8 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("GameInstructions"), gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3);

gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3.length;i<l;++i) {
    if ( gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3[i].isVisible() ) {
        gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = true;
        gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3[k] = gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3[i];
        ++k;
    }
}
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3.length = k;}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("DesktopControls"), gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3);
/* Reuse gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3 */
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3[i].hide();
}
for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3[i].hide();
}
}}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList9 = function(runtimeScene) {

{

gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3.length = 0;


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1 = gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final.length = 0;gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Forward"), gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4);
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2 = gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1;
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDForwardObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val ) {
{
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2.val = true && gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val && gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val;
}
if( gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4.length;j<jLen;++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3);
}
}
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(1).add(100);
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMaxMotorTorque(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("rearJoint")), 50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(1);
}
{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList8(runtimeScene);} //End of subevents
}

}


};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDBackwardObjects4Objects = Hashtable.newFrom({"Backward": gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4});
gdjs.Downhill_32Bike_32DemoCode.eventsList10 = function(runtimeScene) {

{

gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3.length = 0;


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1 = gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final.length = 0;gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
if( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Backward"), gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4);
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2 = gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1;
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDBackwardObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val ) {
{
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2.val = true && gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val && gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val;
}
if( gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4.length;j<jLen;++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3);
}
}
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(1).sub(100);
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMaxMotorTorque(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("rearJoint")), 50);
}
}{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(1);
}}

}


};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDBrakeObjects4Objects = Hashtable.newFrom({"Brake": gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDRightObjects4Objects = Hashtable.newFrom({"Right": gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDLeftObjects4Objects = Hashtable.newFrom({"Left": gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDRetryObjects3Objects = Hashtable.newFrom({"Retry": gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3});
gdjs.Downhill_32Bike_32DemoCode.eventsList11 = function(runtimeScene) {

{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
{runtimeScene.getScene().getVariables().getFromIndex(2).setNumber(0);
}}

}


{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(0));
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList9(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) > -(500);
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(2)) == 0;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
{runtimeScene.getScene().getVariables().getFromIndex(1).mul(0.99);
}}

}


{



}


{

gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3.length = 0;


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1 = gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final.length = 0;gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
if( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Brake"), gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4);
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2 = gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1;
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDBrakeObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val ) {
{
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2.val = true && gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val && gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val;
}
if( gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4.length;j<jLen;++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3);
}
}
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(0);
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMaxMotorTorque(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("rearJoint")), 1000);
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMotorSpeed(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("rearJoint")), 0);
}
}}

}


{



}


{

gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3.length = 0;


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1 = gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final.length = 0;gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Right"), gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4);
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2 = gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1;
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDRightObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val ) {
{
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2.val = true && gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val && gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val;
}
if( gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4.length;j<jLen;++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3);
}
}
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3[i].getBehavior("Physics2").applyTorque(38);
}
}}

}


{

gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3.length = 0;


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1 = gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final.length = 0;gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Left"), gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4);
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2 = gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1;
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDLeftObjects4Objects, runtimeScene, true, false);
}if ( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val ) {
{
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2.val = true && gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val && gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val;
}
if( gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4.length;j<jLen;++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3_1final, gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3);
}
}
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3[i].getBehavior("Physics2").applyTorque(-(38));
}
}}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("BackWheel"), gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3[i].getBehavior("Physics2").setWheelJointMotorSpeed(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("rearJoint")), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)));
}
}}

}


{



}


{

gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2.length = 0;


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1 = gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final.length = 0;gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Escape");
if( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
}
}
{
gdjs.copyArray(runtimeScene.getObjects("Retry"), gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3);
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2 = gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1;
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val = gdjs.evtTools.input.cursorOnObject(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDRetryObjects3Objects, runtimeScene, true, false);
}if ( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val ) {
{
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}}
gdjs.Downhill_32Bike_32DemoCode.conditionTrue_2.val = true && gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_2.val && gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_2.val;
}
if( gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_1.val ) {
    gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = true;
    for(var j = 0, jLen = gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3.length;j<jLen;++j) {
        if ( gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final.indexOf(gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3[j]) === -1 )
            gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final.push(gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3[j]);
    }
}
}
{
gdjs.copyArray(gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2_1final, gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2);
}
}
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "Downhill Bike Demo", false);
}}

}


};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDfloorObjects3ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDJumpObjects3Objects = Hashtable.newFrom({"floor": gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects3, "Jump": gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects3});
gdjs.Downhill_32Bike_32DemoCode.eventsList12 = function(runtimeScene) {

{


{
/* Reuse gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3 */
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3[i].setPosition(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(8)),gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(9)));
}
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3.length !== 0 ? gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3[0] : null), true, "", 0);
}}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList13 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects3);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3);
gdjs.copyArray(runtimeScene.getObjects("floor"), gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects3);

gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.object.raycastObject(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDfloorObjects3ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDJumpObjects3Objects, (( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointX("Center")), (( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointY("Center")), 90, 5000, runtimeScene.getScene().getVariables().getFromIndex(6), runtimeScene.getScene().getVariables().getFromIndex(4), true);
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
/* Reuse gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3 */
{runtimeScene.getScene().getVariables().getFromIndex(5).setNumber((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(4)) - ((( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointY("")) - 600)));
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, (300 / gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(5))), "", 0);
}}

}


{



}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Follow"), gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3);
{runtimeScene.getScene().getVariables().getFromIndex(8).setNumber(gdjs.evtTools.common.lerp((( gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3[0].getPointX("")), (( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointX("")), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7))));
}{runtimeScene.getScene().getVariables().getFromIndex(9).setNumber(gdjs.evtTools.common.lerp((( gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3[0].getPointY("")), (( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3[0].getPointY("")), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(7))));
}
{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList12(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);
{gdjs.evtTools.camera.setCameraX(runtimeScene, ((( gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2[0].getPointX("")) + 900) / 100, "Background", 0);
}}

}


};gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDFrontWheelObjects2Objects = Hashtable.newFrom({"FrontWheel": gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDStartObjects2Objects = Hashtable.newFrom({"Start": gdjs.Downhill_32Bike_32DemoCode.GDStartObjects2});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDFrontWheelObjects1Objects = Hashtable.newFrom({"FrontWheel": gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects1});
gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDWinObjects1Objects = Hashtable.newFrom({"Win": gdjs.Downhill_32Bike_32DemoCode.GDWinObjects1});
gdjs.Downhill_32Bike_32DemoCode.eventsList14 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2);
gdjs.copyArray(runtimeScene.getObjects("Start"), gdjs.Downhill_32Bike_32DemoCode.GDStartObjects2);

gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDFrontWheelObjects2Objects, gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDStartObjects2Objects, false, runtimeScene, false);
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "elapsedTimer");
}}

}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(11)) == 0;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Elapsed"), gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects2);
{runtimeScene.getScene().getVariables().getFromIndex(12).setNumber(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "elapsedTimer"));
}{runtimeScene.getScene().getVariables().getFromIndex(12).setString(gdjs.evtTools.string.subStr(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(12))), 0, 5));
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects2[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(12)));
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects1);
gdjs.copyArray(runtimeScene.getObjects("Win"), gdjs.Downhill_32Bike_32DemoCode.GDWinObjects1);

gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDFrontWheelObjects1Objects, gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDWinObjects1Objects, false, runtimeScene, false);
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Elapsed"), gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects1);
{runtimeScene.getScene().getVariables().getFromIndex(11).setNumber(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "elapsedTimer"));
}{runtimeScene.getScene().getVariables().getFromIndex(11).setString(gdjs.evtTools.string.subStr(gdjs.evtTools.common.toString(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(12))), 0, 5));
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects1.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects1[i].setString(gdjs.evtTools.variable.getVariableString(runtimeScene.getScene().getVariables().getFromIndex(11)));
}
}}

}


};gdjs.Downhill_32Bike_32DemoCode.eventsList15 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Crank"), gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2);
gdjs.copyArray(runtimeScene.getObjects("FrontSuspensionBottom"), gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2);
gdjs.copyArray(runtimeScene.getObjects("FrontWheel"), gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2);
gdjs.copyArray(runtimeScene.getObjects("MainFrame"), gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2);
gdjs.copyArray(runtimeScene.getObjects("RearSuspension"), gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2);
{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2[i].setPosition((( gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0].getPointX("")),(( gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2[i].setAngle((( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2[i].setAngle((( gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length === 0 ) ? 0 :gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2[0].getAngle()));
}
}{for(var i = 0, len = gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length ;i < len;++i) {
    gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2[i].getBehavior("Physics2").setRevoluteJointMotorSpeed(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().get("crank")), gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(1)) / 4);
}
}}

}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList3(runtimeScene);
}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList4(runtimeScene);
}


{


gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getScene().getVariables().getFromIndex(13)) > 1000;
}if (gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val) {
{gdjs.deviceVibration.startVibration(500);
}
{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList5(runtimeScene);} //End of subevents
}

}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList6(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("Head"), gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2);
gdjs.copyArray(runtimeScene.getObjects("Jump"), gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects2);
gdjs.copyArray(runtimeScene.getObjects("LArm"), gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("LUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("RArm"), gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("RUpperArm"), gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2);
gdjs.copyArray(runtimeScene.getObjects("Torso"), gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2);
gdjs.copyArray(runtimeScene.getObjects("floor"), gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects2);

gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = false;
gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_0.val = false;
{
gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val = gdjs.physics2.objectsCollide(gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDHeadObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDTorsoObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDRArmObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDLArmObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDRUpperArmObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDLUpperArmObjects2Objects, "Physics2", gdjs.Downhill_32Bike_32DemoCode.mapOfGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDfloorObjects2ObjectsGDgdjs_46Downhill_9532Bike_9532DemoCode_46GDJumpObjects2Objects, false);
}if ( gdjs.Downhill_32Bike_32DemoCode.condition0IsTrue_0.val ) {
{
{gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1 = gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_0;
gdjs.Downhill_32Bike_32DemoCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9197836);
}
}}
if (gdjs.Downhill_32Bike_32DemoCode.condition1IsTrue_0.val) {
{gdjs.deviceVibration.startVibration(500);
}
{ //Subevents
gdjs.Downhill_32Bike_32DemoCode.eventsList7(runtimeScene);} //End of subevents
}

}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList11(runtimeScene);
}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList13(runtimeScene);
}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList14(runtimeScene);
}


};gdjs.Downhill_32Bike_32DemoCode.eventsList16 = function(runtimeScene) {

{


gdjs.Downhill_32Bike_32DemoCode.eventsList1(runtimeScene);
}


{


gdjs.Downhill_32Bike_32DemoCode.eventsList15(runtimeScene);
}


};

gdjs.Downhill_32Bike_32DemoCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDMainFrameObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontWheelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackWheelObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDfloorObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTimingObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDElapsedObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRearSuspensionObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFrontSuspensionBottomObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSeatObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCrankObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRPedalObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLPedalObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTorsoObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightThighObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftThighObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightLegObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftLegObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRUpperArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLUpperArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLArmObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDHeadObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDFollowObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDWinObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDStartObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceStrengthObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDDesktopControlsObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGameInstructionsObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDJumpObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForwardObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackwardObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBrakeObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRetryObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDLeftObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDRightObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTrackObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDCliffObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBackgroundObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDTreeObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDBushObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDGrassObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDSignObjects5.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects1.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects2.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects3.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects4.length = 0;
gdjs.Downhill_32Bike_32DemoCode.GDForceIndicatorObjects5.length = 0;

gdjs.Downhill_32Bike_32DemoCode.eventsList16(runtimeScene);

return;

}

gdjs['Downhill_32Bike_32DemoCode'] = gdjs.Downhill_32Bike_32DemoCode;
